PE Bilingual Buddy V3

NEW IN V3:
- Search bar searches BOTH English and Spanish phrases.
- Search results work in either Teacher Mode or Student Mode.
- Category buttons still organize phrases into Basics, PE Movements, Games, Student Needs, and Directions.

Teacher Mode: press English -> hear Spanish.
Student Mode: press Spanish -> hear English.

Open index.html in Chrome or Edge.
For GitHub Pages, upload/replace index.html in your repository and commit the change.
